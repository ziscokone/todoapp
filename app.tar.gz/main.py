from flet import *


def main(page: Page):
    # Définition des couleurs
    BG = '#041955'
    FWG = '#97b4ff'
    FG = '#3450a1'
    PINK = '#eb06ff'
    

    # Creation de task view 
    create_task_view = Container(
        content=Column(
            controls=[
                Icon(icons.DELETE)
            ]
        )
    )

    # Fonction de creation de route 
    def route_change(route):
        # vider la page 
        page.views.clear()
        page.views.append('/',[container])

    # Interface de tâches 
    task = Column()

    # Cadre des categories
    categories_card=Row(scroll='auto')
    categories = ['Business', 'Famille', 'Amis']
    # Ajout des cotegories dans le cadre des categories 
    for i, categorie in enumerate(categories):
        categories_card.controls.append(
            Container(
                bgcolor=BG,
                height=110,
                width=170,
                border_radius=20,
                padding=15,

                content=Column(
                    controls=[
                        Text('40 Tâches', color="white"),
                        Text(categorie, color="white"),
                        # Progress bar
                        Container(
                            width=160,
                            height=5,
                            bgcolor='white12',
                            border_radius=20,
                            padding=padding.only(right= i*30),
                            content=Container(bgcolor=PINK)
                        )
                    ]
                )
            )
        )

    # Contenu 
    first_page_contents = Container(
        content=Column(
            controls=[
                # Premiere ligne contenant le menu et les icons (notif et search)
                Row(
                    alignment="spaceBetween",
                    controls=[
                        Container(
                            content=Icon(icons.MENU,color='white')),
                        Row(
                            controls=[
                                Icon(icons.SEARCH, color='white'),
                                Icon(icons.NOTIFICATION_ADD_OUTLINED, color='white')
                            ]
                        )
                    ]
                ),
                # séparateur 
                Container(height=20),
                # Deuxieme section 
                Text(value="Bienvenue M. KONE ZISSONGUI SOUMAILA", color="white"),
                Text(value="CATEGORIES" , color="white"),

                Container(
                    padding=padding.only(top=10, bottom=20),
                    content=categories_card
                ),
                Container(height=20),
                Text('TACHE D\'AUJOURDHUI', color="white"),

                # Creation de stack pour afficher la liste scroll des tâches
                Stack(
                    controls=[
                        # Variable Tâche
                        task,
                        FloatingActionButton(icon=icons.ADD, bgcolor=PINK, on_click=lambda _: page.go('/create_task'))
                    ]
                )


            ]
        )
    )

    # Création de pages 
    page_1 = Container()
    page_2 = Row(
        controls=[
            Container(
                width=400,
                height=850,
                bgcolor=FG,
                border_radius=35,
                padding=padding.only(
                    top=50,
                    left=20,
                    right=20,
                    bottom=5
                ),
                content=Column(
                    controls=[
                        first_page_contents
                    ]
                )
            )
        ]
    )

    # Création de container
    container = Container(
        width=400,
        height=850,
        bgcolor= BG,
        border_radius=35,
        content=Stack(
            controls=[
                page_2
            ]
        )
    )

    pages = {
        '/': View("/", [container]),
        '/create_task': View('/create_task', [create_task_view])
    }

    # Ajout du container a la page
    page.add(container)

    page.on_route_change= route_change
    page.go(page.route)

# Lancer l'application
app(target=main)